//BASE DE UN TRIANGULO
let base = 20;
let altura = 15;

let area = base*altura/2;

console.log("La àrea de el triandulo es de", area, "cm");

//COMPARACION
let a = 8
let b = 30
console.log("¿ numero a >= numero b?:", a >= b);
//NUMERO ENTRE 10 Y 20
let num = 20;

console.log("¿El numero esta entre 10 y 20?:", num >= 10 && num <= 20);

//OPERADORES DE ASIGNASION
let numero = 19;

numero += 5;
numero *= 2;

console.log(numero);

//COMPARAR DOS VALORES Y VER SI SON IGUALES EN VALOR



